
This application requires a postgres database with the name 'car_rental' to be created in order to start with no issues.
To use as ordinary user, register an account.
To use as admin, use following credentials: 
username: admin1@app.com
password: password

Heroku link:
https://simoncarrental.herokuapp.com/

package com.carrental;

import com.carrental.entities.User;
import com.carrental.enums.Role;
import com.carrental.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class SpringSecurityThymeleafApplication implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public SpringSecurityThymeleafApplication(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityThymeleafApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        if(userRepository.count() == 0) {
            User user1 = new User();
            user1.setFirstName("Admin 1");
            user1.setLastName("Admin 1");
            user1.setPhoneNumber("2222222222");
            user1.setEmail("admin1@app.com");
            user1.setPassword(passwordEncoder.encode("password"));
            user1.setRole(Role.ROLE_ADMIN);

            User user2 = new User();
            user2.setFirstName("Admin 2");
            user2.setLastName("Admin 2");
            user2.setPhoneNumber("3333333333");
            user2.setEmail("admin2@app.com");
            user2.setPassword(passwordEncoder.encode("password"));
            user2.setRole(Role.ROLE_ADMIN);

            userRepository.save(user1);
            userRepository.save(user2);
        }
    }
}

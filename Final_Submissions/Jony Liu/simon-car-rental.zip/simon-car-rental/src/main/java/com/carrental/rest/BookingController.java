package com.carrental.rest;

import com.carrental.entities.Booking;
import com.carrental.entities.User;
import com.carrental.repositories.BookingRepository;
import com.carrental.repositories.CarRepository;
import com.carrental.repositories.UserRepository;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.List;

@Controller
@Validated
@RequestMapping(value = "bookings")
public class BookingController {

    private final CarRepository carRepository;
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;

    public BookingController(CarRepository carRepository, BookingRepository bookingRepository, UserRepository userRepository) {
        this.carRepository = carRepository;
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ModelAndView bookings(Principal principal) {
        User user = userRepository.findByEmail(principal.getName());
        List<Booking> bookings=bookingRepository.findByCustomerId(user.getId());
        ModelAndView modelAndView = new ModelAndView("bookings");
        modelAndView.addObject("bookings", bookings);
        return modelAndView;
    }


}

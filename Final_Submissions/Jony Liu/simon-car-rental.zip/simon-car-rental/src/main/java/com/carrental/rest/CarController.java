package com.carrental.rest;

import com.carrental.entities.Booking;
import com.carrental.entities.Car;
import com.carrental.entities.User;
import com.carrental.models.CarSearchRequest;
import com.carrental.repositories.BookingRepository;
import com.carrental.repositories.CarRepository;
import com.carrental.repositories.UserRepository;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.Principal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@Validated
@RequestMapping(value = "cars")
public class CarController {

    private final CarRepository carRepository;
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;

    public CarController(CarRepository carRepository, BookingRepository bookingRepository, UserRepository userRepository) {
        this.carRepository = carRepository;
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ModelAndView carForm() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        System.out.println(authentication.getAuthorities());
        ModelAndView modelAndView = new ModelAndView("admin/create-car");
        modelAndView.addObject("car", new Car());
        return modelAndView;
    }

    @PostMapping
    public void createCar(@RequestParam("image") MultipartFile image, @ModelAttribute @Valid Car car, HttpServletResponse response) throws IOException {
        car.setPhoto(image.getBytes());
        car.setContentType(image.getContentType());
        carRepository.save(car);
        response.sendRedirect("/cars/search");
    }

    @GetMapping(value = "search")
    public ModelAndView searchCars() {

        List<Car> cars = new ArrayList<>();
        ModelAndView modelAndView = new ModelAndView("search-cars");
        modelAndView.addObject("cars", cars);
        modelAndView.addObject("searchDTO", new CarSearchRequest());
        return modelAndView;

    }

    @GetMapping(value = "list")
    public ModelAndView listCars() {

        List<Car> cars = carRepository.findAll();
        ModelAndView modelAndView = new ModelAndView("our-fleet");
        modelAndView.addObject("cars", cars);
        return modelAndView;

    }

    @PostMapping(value = "search")
    public ModelAndView searchCars(@ModelAttribute CarSearchRequest dto) {
        ModelAndView modelAndView = new ModelAndView();

        List<Car> cars = searchCarsByCriteria(dto);

        modelAndView.addObject("cars", cars);
        modelAndView.addObject("searchDTO", dto);
        modelAndView.setViewName("search-cars");
        return modelAndView;
    }

    @GetMapping("image/{id}")
    public void showCarImage(@PathVariable Long id,
                             HttpServletResponse response) throws IOException {

        Car car = carRepository.findById(id).get();

        response.setContentType(car.getContentType());

        if (car.getPhoto() != null) {

            InputStream is = new ByteArrayInputStream(car.getPhoto());
            IOUtils.copy(is, response.getOutputStream());
        }

    }

    @GetMapping(value = "book/{id}/{pickupDate}/{returnDate}/{minPrice}/{maxPrice}")
    public ModelAndView bookCar(@PathVariable Long id, @PathVariable String pickupDate, @PathVariable String returnDate,
                                @PathVariable(required = false) String minPrice, @PathVariable(required = false) String maxPrice, Principal principal) {
        User user = userRepository.findByEmail(principal.getName());
        Car car = carRepository.findById(id).get();


        Booking booking = new Booking();
        booking.setBookingDate(LocalDate.now());
        booking.setPickupDate(LocalDate.parse(pickupDate));
        booking.setReturnDate(LocalDate.parse(returnDate));
        booking.setCustomer(user);
        booking.setCar(car);
        booking.setCarReturned(false);
        long daysBetween = booking.getPickupDate().until(booking.getReturnDate(), ChronoUnit.DAYS);
        booking.setPrice(daysBetween * car.getPrice());
        bookingRepository.save(booking);

        CarSearchRequest dto = new CarSearchRequest();
        dto.setPickupDate(pickupDate);
        dto.setReturnDate(returnDate);
        if (minPrice != null && !"null".equals(minPrice)) {
            dto.setMinPrice(Float.parseFloat(minPrice));
        }
        if (maxPrice != null && !"null".equals(maxPrice)) {
            dto.setMaxPrice(Float.parseFloat(maxPrice));
        }

        List<Car> cars = searchCarsByCriteria(dto);
        ModelAndView modelAndView = new ModelAndView("search-cars");
        modelAndView.addObject("bookingMessage", "Car booked!");
        modelAndView.addObject("bookedCarId", id);
        modelAndView.addObject("searchDTO", dto);
        modelAndView.addObject("cars", cars);
        return modelAndView;
    }

    private List<Car> searchCarsByCriteria(CarSearchRequest dto) {
        List<Car> cars = carRepository.findAll((root, cq, cb) -> {
            final Collection<Predicate> predicates = new ArrayList<>();

            if (!StringUtils.isEmpty(dto.getFuel())) {
                Predicate predicate = cb.equal(root.get("fuel"), dto.getFuel());
                predicates.add(predicate);
            }

            if (!StringUtils.isEmpty(dto.getTransmission())) {
                Predicate predicate = cb.equal(root.get("transmission"), dto.getTransmission());
                predicates.add(predicate);
            }

            if (!StringUtils.isEmpty(dto.getType())) {
                Predicate predicate = cb.equal(root.get("type"), dto.getType());
                predicates.add(predicate);
            }

            if (!StringUtils.isEmpty(dto.getMinPrice())) {
                Predicate predicate = cb.greaterThanOrEqualTo(root.get("price"), dto.getMinPrice());
                predicates.add(predicate);
            }

            if (!StringUtils.isEmpty(dto.getMaxPrice())) {
                Predicate predicate = cb.lessThanOrEqualTo(root.get("price"), dto.getMaxPrice());
                predicates.add(predicate);
            }

            Predicate andPredicate = cb.and(predicates.toArray(new Predicate[predicates.size()]));

            return cb.and(new Predicate[]{andPredicate});
        });


        if (dto.getPickupDate() != null && !dto.getPickupDate().isEmpty() && !"null".equals(dto.getPickupDate())

                && dto.getReturnDate() != null && !dto.getReturnDate().isEmpty() && !"null".equals(dto.getReturnDate())) {
            LocalDate startDate = LocalDate.parse(dto.getPickupDate());
            LocalDate endDate = LocalDate.parse(dto.getReturnDate());
            // Filtering out the cars that are booked in the selected date range
            cars = cars.stream().

                    filter(car ->

                    {
                        List<Booking> bookings = bookingRepository.findByCarIdAndReturnDateGreaterThanAndPickupDateLessThan(car.getId(), startDate, endDate);
                        return bookings.size() == 0;
                    }).

                    collect(Collectors.toList());
        }
        return cars;
    }

}

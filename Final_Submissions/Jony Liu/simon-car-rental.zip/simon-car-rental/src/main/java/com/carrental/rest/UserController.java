package com.carrental.rest;

import com.carrental.entities.User;
import com.carrental.enums.Role;
import com.carrental.repositories.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;

@Controller
@RequestMapping(value = "users")
public class UserController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping(value = "registration")
    public String registrationForm(Model model) {
        model.addAttribute("user", new User());
        return "registration";
    }

    @GetMapping(value = "login")
    public String loginForm(Model model) {
        return "login";
    }

    @PostMapping(value = "registration")
    public ModelAndView registerUser(@ModelAttribute @Valid User user, BindingResult result) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("registration");

        if (userRepository.findByEmail(user.getEmail()) != null) {
            FieldError error = new FieldError("user", "email", "Email already exists");
            result.addError(error);
            return modelAndView;
        }

        if (userRepository.findByPhoneNumber(user.getPhoneNumber()) != null) {
            FieldError error = new FieldError("user", "phoneNumber", "Phone number already exists");
            result.addError(error);
            return modelAndView;
        }

        if (userRepository.count() == 0) {
            user.setRole(Role.ROLE_ADMIN);
        }
        if (user.getPassword() != null) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        if (user.getRole() == null) {
            user.setRole(Role.ROLE_USER);
        }
        userRepository.save(user);

        modelAndView.setViewName("login");
        modelAndView.addObject("registrationSuccess", true);
        return modelAndView;
    }

}

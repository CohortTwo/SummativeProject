package com.carrental.enums;

public enum Role {

    ROLE_USER,
    ROLE_ADMIN
}

package com.carrental.repositories;

import com.carrental.entities.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByCarIdAndPickupDateGreaterThanAndReturnDateLessThan(long id, LocalDate startDate, LocalDate endDate);

    List<Booking> findByCustomerId(long id);

    List<Booking> findByCarIdAndReturnDateGreaterThanAndPickupDateLessThan(long id, LocalDate startDate, LocalDate endDate);
}

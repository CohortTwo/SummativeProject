package com.carrental.entities;

import javax.persistence.*;
import java.time.LocalDate;


@Entity
@Table(name = "BOOKING_TABLE")
public class Booking {

    @Id
    @GeneratedValue
    private long id;

    private LocalDate bookingDate;

    private LocalDate pickupDate;

    private LocalDate returnDate;

    @ManyToOne
    private User customer;

    @ManyToOne
    private Car car;

    private boolean carReturned;

    private Double price;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public LocalDate getPickupDate() {
        return pickupDate;
    }

    public void setPickupDate(LocalDate pickupDate) {
        this.pickupDate = pickupDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public User getCustomer() {
        return customer;
    }

    public void setCustomer(User customer) {
        this.customer = customer;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public boolean isCarReturned() {
        return carReturned;
    }

    public void setCarReturned(boolean carReturned) {
        this.carReturned = carReturned;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}
